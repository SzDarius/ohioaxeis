const QUESTIONS = [
  { text: "Rich people should pay more taxes so poor people can get more help.", axis: "economy", effect: 1 },
  { text: "Private businesses usually do things better than the government.", axis: "economy", effect: -1 },
  { text: "It is okay for the government to spend more money on free health care.", axis: "economy", effect: 1 },
  { text: "People should mostly keep the money they earn.", axis: "economy", effect: -1 },
  { text: "Big companies need more rules so they do not hurt workers.", axis: "economy", effect: 1 },
  { text: "A free market is the best way to make a country strong.", axis: "economy", effect: -1 },

  { text: "Old customs should be protected, even when new ideas are popular.", axis: "culture", effect: -1 },
  { text: "Society gets better when people are open to change.", axis: "culture", effect: 1 },
  { text: "Schools should teach traditional family values.", axis: "culture", effect: -1 },
  { text: "People should be free to live how they want if they hurt no one.", axis: "culture", effect: 1 },
  { text: "It is better to keep things the way they have always been.", axis: "culture", effect: -1 },
  { text: "New ways of living should be accepted more often.", axis: "culture", effect: 1 },

  { text: "People should try to forgive more, even when they are angry.", axis: "heart", effect: 1 },
  { text: "It is fine to be harsh to people who have bad views.", axis: "heart", effect: -1 },
  { text: "Kindness matters more than winning arguments.", axis: "heart", effect: 1 },
  { text: "Some people deserve mockery more than respect.", axis: "heart", effect: -1 },
  { text: "Even people I strongly disagree with should be treated with care.", axis: "heart", effect: 1 },
  { text: "Being mean is okay if it helps my side win.", axis: "heart", effect: -1 },

  { text: "Right and wrong are real and do not change from person to person.", axis: "morality", effect: -1 },
  { text: "What is right or wrong depends a lot on the person and the situation.", axis: "morality", effect: 1 },
  { text: "There are moral rules that all people should follow.", axis: "morality", effect: -1 },
  { text: "People from different cultures can have very different morals, and that is okay.", axis: "morality", effect: 1 },
  { text: "Some acts are always wrong, no matter the reason.", axis: "morality", effect: -1 },
  { text: "Good and bad are often matters of opinion.", axis: "morality", effect: 1 }
];
