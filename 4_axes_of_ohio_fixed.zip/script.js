const app = document.getElementById("app");

const AXES = {
  economy: { left: "Equality", right: "Market" },
  culture: { left: "Progressive", right: "Tradition" },
  heart: { left: "Love", right: "Hate" },
  morality: { left: "Subjective Morality", right: "Objective Morality" }
};

const ANSWERS = [
  { label: "Strongly Agree", value: 2 },
  { label: "Agree", value: 1 },
  { label: "Not Sure", value: 0 },
  { label: "Disagree", value: -1 },
  { label: "Strongly Disagree", value: -2 }
];

let state = {
  started: false,
  index: 0,
  answers: []
};

function saveState() {
  localStorage.setItem("ohio4axes_state", JSON.stringify(state));
}

function loadState() {
  try {
    const raw = localStorage.getItem("ohio4axes_state");
    if (raw) state = JSON.parse(raw);
  } catch (e) {}
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, s => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[s]));
}

function normalize(score, max) {
  const pct = ((score + max) / (2 * max)) * 100;
  return Math.max(0, Math.min(100, Math.round(pct)));
}

function getResults() {
  const totals = {
    economy: { score: 0, max: 0 },
    culture: { score: 0, max: 0 },
    heart: { score: 0, max: 0 },
    morality: { score: 0, max: 0 }
  };

  QUESTIONS.forEach((q, i) => {
    const ans = state.answers[i] ?? 0;
    totals[q.axis].score += ans * q.effect;
    totals[q.axis].max += 2;
  });

  const values = {
    economy: normalize(totals.economy.score, totals.economy.max),
    culture: normalize(totals.culture.score, totals.culture.max),
    heart: normalize(totals.heart.score, totals.heart.max),
    morality: normalize(totals.morality.score, totals.morality.max)
  };

  const matches = ARCHETYPES.map(type => {
    const distance =
      Math.abs(type.economy - values.economy) +
      Math.abs(type.culture - values.culture) +
      Math.abs(type.heart - values.heart) +
      Math.abs(type.morality - values.morality);
    return { ...type, distance };
  }).sort((a, b) => a.distance - b.distance).slice(0, 8);

  return { ...values, matches };
}

function renderHome() {
  app.innerHTML = `
    <div class="card">
      <div class="pill">Funny values test website</div>
      <h1>The 4 Axes of Ohio</h1>
      <p class="muted">Find out where you land on Equality vs Market, Progressive vs Tradition, Love vs Hate, and Subjective Morality vs Objective Morality.</p>
      <div class="grid" style="margin: 18px 0 22px;">
        <div class="axis">Equality vs Market</div>
        <div class="axis">Progressive vs Tradition</div>
        <div class="axis">Love vs Hate</div>
        <div class="axis">Subjective vs Objective Morality</div>
      </div>
      <button class="primary" id="startBtn">Start the test</button>
    </div>
  `;
  document.getElementById("startBtn").onclick = () => {
    state.started = true;
    state.index = 0;
    state.answers = [];
    saveState();
    render();
  };
}

function renderQuiz() {
  const q = QUESTIONS[state.index];
  const progress = Math.round((state.index / QUESTIONS.length) * 100);
  app.innerHTML = `
    <div class="small">Question ${state.index + 1} of ${QUESTIONS.length}</div>
    <div class="progress"><div style="width:${progress}%"></div></div>
    <div class="card">
      <div class="pill">The 4 Axes of Ohio</div>
      <h2>${escapeHtml(q.text)}</h2>
      <div class="answers" id="answers"></div>
    </div>
  `;
  const answersEl = document.getElementById("answers");
  ANSWERS.forEach(opt => {
    const btn = document.createElement("button");
    btn.className = "answer";
    btn.textContent = opt.label;
    btn.onclick = () => {
      state.answers.push(opt.value);
      state.index += 1;
      saveState();
      render();
    };
    answersEl.appendChild(btn);
  });
}

function renderResults() {
  const results = getResults();
  const axisCard = (key, value) => `
    <div class="axis">
      <div class="row"><strong>${AXES[key].left}</strong><strong>${AXES[key].right}</strong></div>
      <div class="bar"><div class="fill" style="width:${value}%"></div></div>
      <div class="row small"><span>${value}% ${AXES[key].left}</span><span>${100 - value}% ${AXES[key].right}</span></div>
    </div>
  `;
  app.innerHTML = `
    <div class="card">
      <div class="pill">Your Ohio results</div>
      <h1>You are closest to: ${escapeHtml(results.matches[0].name)}</h1>
      <p class="muted">${escapeHtml(results.matches[0].blurb)}</p>
    </div>

    <div class="grid" style="margin-top:16px;">
      ${axisCard("economy", results.economy)}
      ${axisCard("culture", results.culture)}
      ${axisCard("heart", results.heart)}
      ${axisCard("morality", results.morality)}
    </div>

    <div class="card" style="margin-top:16px;">
      <h2>Your closest types</h2>
      <div class="grid">
        ${results.matches.map((m, i) => `
          <div class="match">
            <div class="small">#${i + 1} Match</div>
            <h3>${escapeHtml(m.name)}</h3>
            <p class="muted">${escapeHtml(m.blurb)}</p>
          </div>
        `).join("")}
      </div>
      <div style="margin-top:18px;">
        <button class="primary" id="restartBtn">Take it again</button>
      </div>
    </div>
  `;
  document.getElementById("restartBtn").onclick = () => {
    state = { started: false, index: 0, answers: [] };
    saveState();
    render();
  };
}

function render() {
  if (!state.started) return renderHome();
  if (state.index >= QUESTIONS.length) return renderResults();
  renderQuiz();
}

loadState();
render();
