const ARCHETYPES = [
  { name: "The Kind Comrade", economy: 86, culture: 82, heart: 95, morality: 72, blurb: "You want more fairness, more change, more kindness, and flexible morals." },
  { name: "The Soft Progressive", economy: 72, culture: 88, heart: 91, morality: 64, blurb: "You care a lot about change and empathy, with a fairly equal economy view." },
  { name: "The Rules With Heart", economy: 61, culture: 48, heart: 87, morality: 18, blurb: "You are caring, but you still believe in firm moral truth." },
  { name: "The Sunday Populist", economy: 67, culture: 28, heart: 78, morality: 22, blurb: "You like helping ordinary people, but you also like tradition and clear morals." },
  { name: "The Free Market Nice Guy", economy: 24, culture: 57, heart: 80, morality: 45, blurb: "You trust markets more, but you still care about people and freedom." },
  { name: "The Chill Centrist", economy: 50, culture: 50, heart: 70, morality: 50, blurb: "You are balanced on most things and do not go too far in one direction." },
  { name: "The Debate Goblin", economy: 41, culture: 60, heart: 16, morality: 57, blurb: "You like ideas and conflict more than soft feelings." },
  { name: "The Law and Order Trader", economy: 20, culture: 19, heart: 32, morality: 10, blurb: "You like markets, tradition, toughness, and fixed moral rules." },
  { name: "The Chaos Poster", economy: 48, culture: 84, heart: 12, morality: 86, blurb: "You like change and personal choice, but you do not care much about being gentle." },
  { name: "The Church Dad Capitalist", economy: 18, culture: 20, heart: 69, morality: 14, blurb: "You like markets and tradition, but you still believe in kindness and duty." },
  { name: "The Ohio Moderate", economy: 54, culture: 44, heart: 62, morality: 41, blurb: "You are in the middle, with a slight lean toward fairness and kindness." },
  { name: "The Love Wins Reformer", economy: 77, culture: 93, heart: 98, morality: 79, blurb: "You strongly support equality, progress, compassion, and flexible morality." },
  { name: "The Hardline Grandpa", economy: 26, culture: 8, heart: 21, morality: 6, blurb: "You strongly favor markets, tradition, toughness, and objective morals." },
  { name: "The Good Vibes Neighbor", economy: 58, culture: 63, heart: 89, morality: 58, blurb: "You care most about getting along and treating people well." },
  { name: "The Edgy Absolutist", economy: 37, culture: 35, heart: 9, morality: 8, blurb: "You can be harsh, skeptical of change, and very certain about right and wrong." },
  { name: "The Friendly Traditionalist", economy: 43, culture: 23, heart: 86, morality: 24, blurb: "You are old-school in many ways, but you still want people treated kindly." }
];
