# The 4 Axes of Ohio

## Open locally
Unzip the folder and open `index.html`.

## Upload to GitHub Pages
1. Make a new GitHub repo.
2. Upload all files.
3. Go to Settings -> Pages.
4. Set Branch to `main` and folder to `/root`.
5. Save.
